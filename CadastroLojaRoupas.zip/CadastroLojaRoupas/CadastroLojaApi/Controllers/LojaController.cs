using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using CadastroProdutoApi.Models;
using CadastroProdutoApi.DAOs;
using CadastroProdutoApi.Controllers.Extensoes;
using CadastroProdutoDll.DOs;

namespace CadastroProdutoApi.Controllers
{
        [ApiController]
    [Route("api/[controller]")]
    public class ProdutoController : ControllerBase
    {
        // GET: api/Produto
        [HttpGet]
        public async Task<ActionResult<IList<ProdutoDO>>> Get()
        {
            return Ok((await dao.RetornarTodosAsync()).ToDO());
        }

        // GET: api/Produto/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ProdutoDO>> GetPorId(string id)
        {
            var objeto = await dao.RetornarPorIdAsync(id);

            if (objeto == null)
                return NotFound();
            
            return Ok(objeto.ToDO());
        }

        // POST: api/Produto
        [HttpPost]
        public async Task<ActionResult<ProdutoDO>> Post(ProdutoDO objDO)
        {
            if (objDO == null)
                return Problem("O Produto que você está tentando inserir está nulo.");

            var objeto = await objDO.ToModel();

            await dao.InserirAsync(objeto);

            objDO = objeto.ToDO();

            return CreatedAtAction(nameof(GetPorId), new { id = objDO.Id }, objDO);
        }

        // PUT: api/Produto/5
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(string id, ProdutoDO novoProdutoDO)
        {
            if (id != novoProdutoDO.Id)
                return Problem("Como você pode me enviar um id na rota diferente do id do objeto?");
                //return BadRequest();
            
            try
            {
                await dao.AlterarAsync(await novoProdutoDO.ToModel());
            }
            catch (Exception)
            {
                throw;
            }

            return NoContent();
        }

        // DELETE: api/Produto/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            await dao.ExcluirAsync(id);
            
            return NoContent();
        }

        private ProdutoDAO dao = new ProdutoDAO();
    }
}