using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CadastroProdutoApi.Models
{
    public class BaseModel
    {
        public string? Id { get; set; }
    }
}