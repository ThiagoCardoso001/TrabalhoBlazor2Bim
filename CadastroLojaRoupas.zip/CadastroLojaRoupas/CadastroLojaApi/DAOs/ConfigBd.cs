﻿namespace CadastroProdutoApi.DAOs
{
    public static class ConfigBd
    {
        public static string StringConexao { get; set; } = "";
    }
}
