CREATE DATABASE loja;
USE loja;
CREATE TABLE loja (
    id VARCHAR(50) PRIMARY KEY,
    nome VARCHAR(50),
    fabricante VARCHAR (50),
    marca VARCHAR (50)
);

CREATE TABLE loja_record (
    id VARCHAR(100) PRIMARY KEY,
    data datetime,
    IdAtleta VARCHAR(100),
    FOREIGN KEY (IdLoja) REFERENCES loja(id) ON DELETE CASCADE
);